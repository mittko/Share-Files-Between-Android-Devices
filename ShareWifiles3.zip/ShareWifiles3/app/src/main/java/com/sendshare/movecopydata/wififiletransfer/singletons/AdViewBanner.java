package com.sendshare.movecopydata.wififiletransfer.singletons;

import android.content.Context;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;

public class AdViewBanner {
    private static final AdViewBanner ourInstance = new AdViewBanner();

    public static AdViewBanner getInstance() {
        return ourInstance;
    }

    private AdView realAdView;
    private AdView testAdView;

    public AdView createRealAdView(Context context, String unitId) {
        if(realAdView == null) {
            realAdView = new AdView(context);//(new WeakReference<Context>(getContext()).get());
            realAdView.setAdSize(AdSize.SMART_BANNER);
            realAdView.setAdUnitId(unitId);
            AdRequest adRequest = new AdRequest.Builder().build(); // real device
            realAdView.loadAd(adRequest);
        }
        return realAdView;
    }
    public AdView createTestAdView(Context context, String unitId) {
        if(testAdView == null) {
            testAdView = new AdView(context);//(new WeakReference<Context>(getContext()).get());
            testAdView.setAdSize(AdSize.SMART_BANNER);
            testAdView.setAdUnitId(unitId);
            AdRequest adRequest =
                    new AdRequest.Builder().addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                            .addTestDevice("D439C5AF6B7EC07A8E301695DB334A4D")
                            .build();
            testAdView.loadAd(adRequest);
        }
        return  testAdView;
    }
    private AdViewBanner() { }

}
