package com.sendshare.movecopydata.wififiletransfer.activities;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.GridView;
import android.widget.LinearLayout;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.ads.AdView;
import com.sendshare.movecopydata.wififiletransfer.adapters.GridViewAdapter;
import com.sendshare.movecopydata.wififiletransfer.singletons.AdViewBanner;
import com.sendshare.movecopydata.wififiletransfer.tasks.FileTransferTask;
import com.sendshare.movecopydata.wififiletransfer.tasks.FileTransferTask2;
import com.sendshare.movecopydata.wififiletransfer.ui.CircleCustomView;
import com.sendshare.movecopydata.wififiletransfer.ui.CustomView;
import com.sendshare.movecopydata.wififiletransfer.ui.SharedCircleCustomView;
import com.sendshare.movecopydata.wififiletransfer.utilities.Konstants;
import com.sendshare.movecopydata.wififiletransfer.utilities.MyConsole;
import com.sendshare.movecopydata.wififiletransfer.utilities.MyDialog;
import com.sendshare.movecopydata.wififiletransfer.utilities.MyUtility;
import com.wifi.mitko.sharewifiles3.R;

import java.io.File;
import java.util.ArrayList;

public class FileTransferActivity2 extends AppCompatActivity {

    private ArrayList<FileTransferTask2> fileTransferTasks =
            new ArrayList<>();
    private AdView adView;

    private long ALL_BYTES_TO_SEND = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_transfer);

        initActionBar();

        String targetIp = getIntent().getStringExtra(Konstants.DEVICE_IP);
        int targetPort = getIntent().getIntExtra(Konstants.DEVICE_RECEIVER_PORT,0);

        ArrayList<CustomView> linearCustomViews =
                new ArrayList<>();
        for(String str : MyUtility.filesToSend) {
            int lastSplash = str.lastIndexOf("/");
            String fileName = "";
            if(lastSplash != -1) {
                fileName = str.substring(lastSplash+1);
            }
        /*    CustomView linearCustomView = new CustomView(this);
            linearCustomViews.add(linearCustomView);

*/
            long bytesToSend = new File(str).length();
            MyConsole.println("bytesToSend = " + bytesToSend);
            ALL_BYTES_TO_SEND += bytesToSend;

        }

      //  MyDialog.showDialog("FILES_SIZE_IN_BYTES = " + ALL_BYTES_TO_SEND,this);
      //  MyConsole.println("FILES_SIZE_IN_BYTES = " + ALL_BYTES_TO_SEND);

        SharedCircleCustomView sharedCircleCustomView =
               addSharedCustomView("fak you");

        LinearLayout linearLayout =
                findViewById(R.id.shared_circle_view_container);
        linearLayout.addView(sharedCircleCustomView);


        LinearLayout belowView =
                findViewById(R.id.below);
      //  belowView.setAdapter(new GridViewAdapter(linearCustomViews));



        int v = 0;
        for(String  filepath : MyUtility.filesToSend) {
              //   CustomView customView = addCustomView(linearLayout, filepath);
            CustomView linearCustomView = addCustomView(filepath);
            linearCustomView.setFilepath(filepath);
            belowView.addView(linearCustomView);

            FileTransferTask2 fileTransferTask =
                    new FileTransferTask2(targetIp, targetPort,
                            filepath,ALL_BYTES_TO_SEND, sharedCircleCustomView, linearCustomView);
            v++;
            fileTransferTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            fileTransferTasks.add(fileTransferTask);
        }

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }


    private CircleCustomView addCustomView2(String fileName) {
        int viewHeight =
                (int)( MyUtility.getHeightInPixels(this)/4);
        int viewWidth =
                (int)(MyUtility.getWidthInPixels(this));///2);
        LinearLayout.LayoutParams layoutParams =
                new LinearLayout.LayoutParams(viewWidth,
                        viewHeight);
        final CircleCustomView customView = new CircleCustomView(fileName,this);
        customView.setLayoutParams(layoutParams);
        return customView;
    }

    private SharedCircleCustomView addSharedCustomView(String fileName) {
        int viewHeight =
               MyUtility.dpToPx(50,this);// ()int)( MyUtility.getHeightInPixels(this)/2);
        int viewWidth =
                (int)(MyUtility.getWidthInPixels(this));///2);
        LinearLayout.LayoutParams layoutParams =
                new LinearLayout.LayoutParams(viewWidth,
                        viewHeight);
        final SharedCircleCustomView customView = new SharedCircleCustomView(fileName,this);
        customView.setLayoutParams(layoutParams);
        return customView;
    }
    private  CustomView addCustomView(String fileName) {
        int viewHeight =
                (int)( MyUtility.getHeightInPixels(this)/4);
        int viewWidth =
                (int)(MyUtility.getWidthInPixels(this));
        LinearLayout.LayoutParams layoutParams =
                new LinearLayout.LayoutParams(viewWidth,
                        viewHeight);
        final CustomView customView = new CustomView(this);
        customView.setWIDTH(viewWidth);
        customView.setHEIGHT(viewHeight);
        customView.setLayoutParams(layoutParams);
        return customView;
    }

    @Override
    protected void onStop() {
        destroyAds();
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
   //     createTestAds();
    }

    @Override
    protected void onDestroy() {
        destroyTasks();
        clearSelectedViews();
        destroyAds();
        super.onDestroy();

    }
    private void destroyAds() {
        LinearLayout adsParent = findViewById(R.id.ads_parent);
        if(adsParent != null)
            adsParent.removeAllViews();
        if(adView != null) {
            adView.destroy();
            adView = null;
        }
    }
    private void createTestAds() {
        LinearLayout parent = findViewById(R.id.ads_parent);
        AdView adView = AdViewBanner.getInstance().
                createTestAdView(getApplicationContext(),getString(R.string.test_banner_unitId));
        parent.addView(adView);
    }
   /* private void createRealAds() {
        LinearLayout parent = findViewById(R.id.ads_parent);
        AdView adView = AdViewBanner.getInstance()
                .createRealAdView(getApplicationContext(),
                        getString(R.string.real_banner_unitId));
        parent.addView(adView);
    }*/
    private void destroyTasks() {
        for(FileTransferTask2 tasks : fileTransferTasks) {
            tasks.cancel(true);
        }
    }

    private void clearSelectedViews() {
        MyUtility.filesToSend.clear();
    }

    private void initActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            actionBar.setDisplayShowCustomEnabled(true);
            ActionBar.LayoutParams layoutParams =
                    new ActionBar.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT
                    );
            View view = LayoutInflater.from(this).inflate(R.layout.ads_container,null);
            actionBar.setCustomView(view,layoutParams);
            Toolbar parent =(Toolbar) view.getParent();
            parent.setPadding(0,0,0,0);//for tab otherwise give space in tab
            parent.setContentInsetsAbsolute(0,0);
        }
    }

}
