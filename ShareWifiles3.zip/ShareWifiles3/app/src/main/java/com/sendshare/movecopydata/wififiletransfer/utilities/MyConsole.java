package com.sendshare.movecopydata.wififiletransfer.utilities;

import android.util.Log;

public class MyConsole {

    public static void println(String msg) {
        Log.e(" >",msg+"\n");
    }
}
