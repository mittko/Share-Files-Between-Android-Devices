package com.sendshare.movecopydata.wififiletransfer.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sendshare.movecopydata.wififiletransfer.modules.GlideApp;
import com.sendshare.movecopydata.wififiletransfer.utilities.MyUtility;
import com.wifi.mitko.sharewifiles3.R;

import java.util.ArrayList;
import java.util.HashSet;

public class RecyclerViewAdapter3 extends RecyclerView.Adapter<RecyclerViewAdapter3.MyViewHolder2>
{

    private ArrayList<ListRow> rowArrayList = new ArrayList<>();
    private Context context;
    private int pageNumber;
    private HashSet<TextView> selectedViews = new HashSet<>();
    public RecyclerViewAdapter3(Context context, int pageNumber) {
        this.pageNumber = pageNumber;
        this.context = context;
    }
    public void clearList() {
        rowArrayList.clear();
        notifyDataSetChanged();
    }

    public void updateList(ArrayList<ListRow> newList) {
        int position = rowArrayList.size();
        rowArrayList.addAll(newList);
        //   MyConsole.println("recyclerview size = "+rowArrayList.size());
        notifyItemRangeInserted(position, newList.size());
    }

    public void clearMemoryFromImages() {
        GlideApp.get(context).clearMemory();
    }
    @Override
    public void onViewRecycled(@NonNull MyViewHolder2 holder) {
        super.onViewRecycled(holder);
        ImageView imageView = (holder.view).findViewById(R.id.thumbnail_imageview);
        GlideApp.with(context).clear(imageView);
    }

    @NonNull
    @Override
    public MyViewHolder2 onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        //  context = viewGroup.getContext();
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.recyclerview_row3,viewGroup,false);
        return new MyViewHolder2(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder2 myViewHolder,final int i) {

        final TextView textView = (myViewHolder.view).findViewById(R.id.file_textview);
        if (rowArrayList.get(i).isChecked()) {
            textView.setTextColor(context.getResources().getColor(R.color.start_color));
        } else {
            textView.setTextColor(Color.BLACK);
        }
        String file = rowArrayList.get(i).getPath();

        int index =  file.lastIndexOf("/");
        String fileName = file;
        if(index != -1) {
            fileName = file.substring(index + 1);
        }
        textView.setText(fileName);

        ImageView imageView = (myViewHolder.view).findViewById(R.id.thumbnail_imageview);

        switch (pageNumber) {
                     case 0 :
                         GlideApp.with(context).load(file).placeholder(R.drawable.video).into(imageView);
                         break;
                     case  1 :
                         GlideApp.with(context).load(file).placeholder(R.drawable.image).into(imageView);
                         break;
                     case 2 :
                         GlideApp.with(context).load(coverpicture(file)).placeholder(R.drawable.audio_).into(imageView);
                         break;
                     case 3 :
                         GlideApp.with(context).load(file).placeholder(R.drawable.document_).into(imageView);
                         break;
                     default:  break;
                 }
    }

    @Override
    public int getItemCount() {
        return rowArrayList.size();
    }


    class MyViewHolder2  extends RecyclerView.ViewHolder {

        private View view;

        MyViewHolder2(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            final TextView textView = view.findViewById(R.id.file_textview);
            final LinearLayout linearLayout = view.findViewById(R.id.linearlayout_recyvlerview_row);
            linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    boolean selected = rowArrayList.get(getAdapterPosition()).isChecked();//linearLayout.isSelected();
                    boolean b = !selected;
                    rowArrayList.get(getAdapterPosition()).setChecked(b);
                    if(b) {
                        textView.setTextColor(context.getResources().getColor(R.color.start_color));
                        MyUtility.filesToSend.add(rowArrayList.get(getAdapterPosition()).getPath());
                         selectedViews.add(textView);
                    } else {
                        textView.setTextColor(Color.BLACK);
                        MyUtility.filesToSend.remove(rowArrayList.get(getAdapterPosition()).getPath());
                        selectedViews.remove(textView);
                    }
                }
            });

        }
    }


    private Bitmap coverpicture(String path) {
        MediaMetadataRetriever mr = new MediaMetadataRetriever();
        mr.setDataSource(path);
        byte[] byte1 = mr.getEmbeddedPicture();
        mr.release();
        if (byte1 != null)
            return BitmapFactory.decodeByteArray(byte1, 0, byte1.length);
        else
            return null;
    }



  /*  private boolean isDirectory(String path) {
        File file = new File(path);
        if(!file.exists()) {
            return true;
        }
        return  file.isDirectory();
    }*/

  public void clearSelectedItems() {
      for(TextView textView : selectedViews) {
          textView.setTextColor(Color.BLACK);
      }
      selectedViews.clear();
     for(ListRow listRow  :   rowArrayList) {
          listRow.setChecked(false);
      }
     notifyDataSetChanged();
  }

}

