package com.sendshare.movecopydata.wififiletransfer.interfaces;

public interface VisualizeDataTransfer {
     void visualize(double value);

     void handleConnectionError(String text);
}
