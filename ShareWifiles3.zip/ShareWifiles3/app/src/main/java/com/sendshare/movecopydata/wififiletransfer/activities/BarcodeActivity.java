/*
package com.sendshare.movecopydata.wififiletransfer.activities;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import android.widget.ImageView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.sendshare.movecopydata.wififiletransfer.servers.MyServer;
import com.sendshare.movecopydata.wififiletransfer.singletons.Interestial;
import com.sendshare.movecopydata.wififiletransfer.utilities.MyConsole;
import com.sendshare.movecopydata.wififiletransfer.utilities.MyUtility;
import com.wifi.mitko.sharewifiles3.R;

public class BarcodeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Interestial.getInstance().createAd(getApplicationContext());
        setContentView(R.layout.activity_barcode);
        ImageView barcodeView = findViewById(R.id.barcode_view);
        try {
            String data = MyUtility.getWifi_IPAddress(this) + "^" + MyServer.getServerPort();
            Bitmap bitmap = encodeAsBitmap(data);
            barcodeView.setImageBitmap(bitmap);
        } catch (WriterException e) {
            MyConsole.println("from BarcodeActivity " + e.getMessage());
        }

        initActionBar();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }


    Bitmap encodeAsBitmap(String text) throws WriterException {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getMetrics(displayMetrics);
        int WIDTH = displayMetrics.widthPixels;//
        int HEIGHT = displayMetrics.heightPixels;//
        try {
            BitMatrix bitMatrix = new QRCodeWriter().encode(text,
                    BarcodeFormat.QR_CODE, WIDTH, HEIGHT);
            int[] pixels = new int[WIDTH * HEIGHT];
            for (int i = 0; i < HEIGHT; i++) {
                for (int j = 0; j < WIDTH; j++) {
                    if (bitMatrix.get(j, i)) {
                        pixels[i * WIDTH + j] =  0x00000000;//0xFFFFFFFF;//
                    } else {
                        pixels[i * WIDTH + j] = 0xFFFFFFFF;//0x282946;
                    }
                }
            }
            return Bitmap.createBitmap(pixels, WIDTH, HEIGHT, Bitmap.Config.ARGB_8888);
        } catch (WriterException e) {
            MyConsole.println("from BarcodeActivity " + e.getMessage());
        }
        return null;
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
   //     Interestial.getInstance().showAd();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
    //    Interestial.getInstance().showAd();
        return super.onSupportNavigateUp();
    }
    private void initActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

}
*/
