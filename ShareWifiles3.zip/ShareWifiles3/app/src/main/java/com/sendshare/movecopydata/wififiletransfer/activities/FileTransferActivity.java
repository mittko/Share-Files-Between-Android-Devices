/*
package com.sendshare.movecopydata.wififiletransfer.activities;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.GridView;
import android.widget.LinearLayout;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.ads.AdView;
import com.sendshare.movecopydata.wififiletransfer.adapters.GridViewAdapter;
import com.sendshare.movecopydata.wififiletransfer.singletons.AdViewBanner;
import com.sendshare.movecopydata.wififiletransfer.tasks.FileTransferTask;
import com.sendshare.movecopydata.wififiletransfer.ui.CircleCustomView;
import com.sendshare.movecopydata.wififiletransfer.utilities.Konstants;
import com.sendshare.movecopydata.wififiletransfer.utilities.MyConsole;
import com.sendshare.movecopydata.wififiletransfer.utilities.MyUtility;
import com.wifi.mitko.sharewifiles3.R;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;

public class FileTransferActivity extends AppCompatActivity {

    private ArrayList<FileTransferTask> fileTransferTasks =
            new ArrayList<>();
    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_transfer);

        initActionBar();

        String targetIp = getIntent().getStringExtra(Konstants.DEVICE_IP);
        int targetPort = getIntent().getIntExtra(Konstants.DEVICE_RECEIVER_PORT,0);

        ArrayList<CircleCustomView> circleCustomViews =
                new ArrayList<>();
        for(String str : MyUtility.filesToSend) {
            int lastSplash = str.lastIndexOf("/");
            String fileName = "";
            if(lastSplash != -1) {
                fileName = str.substring(lastSplash+1);
            }
            CircleCustomView circleCustomView =
                    addCustomView2(fileName);
            circleCustomViews.add(circleCustomView);

        }

        GridView gridView =
                findViewById(R.id.gridview_circlecustomview);
        gridView.setAdapter(new GridViewAdapter(circleCustomViews));
        int v = 0;
        for(String  filepath : MyUtility.filesToSend) {
            //     CustomView customView = addCustomView(linearLayout, filepath);
            FileTransferTask fileTransferTask =
                    new FileTransferTask(targetIp, targetPort,
                            filepath, circleCustomViews.get(v));
            v++;
            fileTransferTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            fileTransferTasks.add(fileTransferTask);
        }

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }


    private CircleCustomView addCustomView2(String fileName) {
        int viewHeight =
                (int)( MyUtility.getHeightInPixels(this)/4);
        int viewWidth =
                (int)(MyUtility.getWidthInPixels(this));///2);
        LinearLayout.LayoutParams layoutParams =
                new LinearLayout.LayoutParams(viewWidth,
                        viewHeight);
        final CircleCustomView customView = new CircleCustomView(fileName,this);
        customView.setLayoutParams(layoutParams);
        return customView;
    }

    @Override
    protected void onStop() {
        destroyAds();
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        createTestAds();
    }

    @Override
    protected void onDestroy() {
        destroyTasks();
        clearSelectedViews();
        destroyAds();
        super.onDestroy();

    }
    private void destroyAds() {
        LinearLayout adsParent = findViewById(R.id.ads_parent);
        if(adsParent != null)
            adsParent.removeAllViews();
        if(adView != null) {
            adView.destroy();
            adView = null;
        }
    }
    private void createTestAds() {
        LinearLayout parent = findViewById(R.id.ads_parent);
        AdView adView = AdViewBanner.getInstance().
                createTestAdView(getApplicationContext(),getString(R.string.test_banner_unitId));
        parent.addView(adView);
    }
   */
/* private void createRealAds() {
        LinearLayout parent = findViewById(R.id.ads_parent);
        AdView adView = AdViewBanner.getInstance()
                .createRealAdView(getApplicationContext(),
                        getString(R.string.real_banner_unitId));
        parent.addView(adView);
    }*//*

    private void destroyTasks() {
        for(FileTransferTask tasks : fileTransferTasks) {
            tasks.cancel(true);
        }
    }

    private void clearSelectedViews() {
        MyUtility.filesToSend.clear();
    }

    private void initActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            actionBar.setDisplayShowCustomEnabled(true);
            ActionBar.LayoutParams layoutParams =
                    new ActionBar.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT
                    );
            View view = LayoutInflater.from(this).inflate(R.layout.ads_container,null);
            actionBar.setCustomView(view,layoutParams);
            Toolbar parent =(Toolbar) view.getParent();
            parent.setPadding(0,0,0,0);//for tab otherwise give space in tab
            parent.setContentInsetsAbsolute(0,0);
        }
    }

}
*/
