package com.sendshare.movecopydata.wififiletransfer.utilities;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.util.DisplayMetrics;
import android.view.Display;

import androidx.appcompat.app.AppCompatActivity;

import java.nio.ByteOrder;
import java.util.HashSet;

public class MyUtility {

    public static HashSet<String>
    filesToSend = new HashSet<>();

    public static String getWifi_IPAddress(Context context) {
        WifiManager wifiManager = (WifiManager) (context.getApplicationContext()
                .getSystemService(Context.WIFI_SERVICE));
        int integerIP = wifiManager.getDhcpInfo().ipAddress;
        MyConsole.println(integerIP + "");
        if (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN)) {
            integerIP = Integer.reverseBytes(integerIP);
        }
        return ((integerIP >> 24) & 0xff) + "." +
                ((integerIP >> 16) & 0xff) + "." +
                ((integerIP >> 8) & 0xff) + "." + (integerIP & 0xff);
    }
    public static float getWidthInPixels(AppCompatActivity activity) {
        Display display = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getMetrics(displayMetrics);
        return displayMetrics.widthPixels;
    }
    public static float getHeightInPixels(AppCompatActivity activity) {
        Display display = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getMetrics(displayMetrics);
        return displayMetrics.heightPixels;
    }

    public  static int dpToPx(int dp, Context context) {
        float density = context.getResources()
                .getDisplayMetrics()
                .density;
        return Math.round((float) dp * density);
    }

  public static boolean checkIsWifiOn(Context context) {
      ConnectivityManager connectivityManager
               = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
      NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
      return networkInfo != null
              && networkInfo.getType() == ConnectivityManager.TYPE_WIFI;
  }
}
