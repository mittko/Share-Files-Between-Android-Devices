package com.sendshare.movecopydata.wififiletransfer.activities;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import com.sendshare.movecopydata.wififiletransfer.adapters.DrawerListAdapter2;
import com.sendshare.movecopydata.wififiletransfer.adapters.MyPageAdapter;
import com.sendshare.movecopydata.wififiletransfer.adapters.RecyclerViewAdapter3;
import com.sendshare.movecopydata.wififiletransfer.modules.GlideApp;
import com.sendshare.movecopydata.wififiletransfer.servers.MyServer;
import com.sendshare.movecopydata.wififiletransfer.utilities.FileManager;
import com.wifi.mitko.sharewifiles3.R;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity
  {
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private RecyclerViewAdapter3 recyclerViewAdapter;

    private MyServer myServer = null;
    private ArrayList<AsyncTask> refreshMediaTasks = new ArrayList<>();
      private ViewPager viewPager;
      private boolean permissionGranded = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // do not delete this line code

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

           if( FileManager.verifyStoragePermissions(this) ) {
             permissionGranded = true;
           } else {
               // permission granted in onRequestPermissionsResult()
           }
        } else {
            permissionGranded = true;
        }


        myServer = new MyServer(getApplicationContext());
        myServer.start();

        setContentView(R.layout.activity_main);

        initDrawerLayout();

        initActionBar();
         if(permissionGranded) {
             initViewPager();
         }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
      @Override
      public void onRequestPermissionsResult(int requestCode,
                                             String[] permissions, int[] grantResults) {
          switch (requestCode) {
              case FileManager.REQUEST_EXTERNAL_STORAGE:
                  if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                      Log.e("!!!","Permission granted");
                     initViewPager();
                  } else {
                      Toast.makeText(this, "Access Denied",
                              Toast.LENGTH_SHORT).show();
                  }
                  break;
              default:
                  super.onRequestPermissionsResult(requestCode, permissions,
                          grantResults);
          }
      }

      @Override
    protected void onDestroy() {
        myServer.interrupt();

        for(AsyncTask task : refreshMediaTasks) {
            task.cancel(true);
        }
        if(recyclerViewAdapter != null) {
            recyclerViewAdapter.clearMemoryFromImages();
        }

        super.onDestroy();

       /* RefWatcher refWatcher = MyApplication.getRefWather(this);
        refWatcher.watch(this);*/
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(data != null) {
            Uri uri = data.getData();
            if(uri != null) {
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    final int flags = data.getFlags()
                            & (Intent.FLAG_GRANT_READ_URI_PERMISSION |
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getContentResolver().takePersistableUriPermission(uri, flags);// this line is very important !!!
                    FileManager.saveUserUri(uri,this);
                }
            }
        }
    }

    private void initDrawerLayout() {
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);

        ListView drawerList = findViewById(R.id.drawer_list);
        String[] titles;
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            titles = getResources().getStringArray(R.array.drawer_values_on_and_above_kitkat);
        } else {
            titles = getResources().getStringArray(R.array.drawer_values_below_kitkat);
        }
        ArrayList<String> tit = new ArrayList<>(Arrays.asList(titles));
        DrawerListAdapter2 drawerListAdapter = new DrawerListAdapter2(this, R.layout.custom_listview,
                tit);
        actionBarDrawerToggle  =
                new ActionBarDrawerToggle(this, drawerLayout,R.string.open_drawer,
                        R.string.close_drawer) {
                    @Override
                    public void onDrawerOpened(View drawerView) {
                        super.onDrawerOpened(drawerView);
                        invalidateOptionsMenu();
                    }

                    @Override
                    public void onDrawerClosed(View drawerView) {
                        super.onDrawerClosed(drawerView);
                        invalidateOptionsMenu();
                    }
                };
      /*  actionBarDrawerToggle.getDrawerArrowDrawable().
                setColor(getResources().getColor(android.R.color.holo_blue_bright));*/
        drawerList.setAdapter(drawerListAdapter);
        drawerLayout.setDrawerListener(actionBarDrawerToggle);
    }

    private void initActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
            actionBar.setDisplayShowCustomEnabled(true);
            ActionBar.LayoutParams layoutParams =
                    new ActionBar.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT
                    );
            View view = LayoutInflater.from(this).inflate(R.layout.custom_actionbar2,null);
            actionBar.setCustomView(view,layoutParams);
            Toolbar parent =(Toolbar) view.getParent();
            parent.setPadding(0,0,0,0);//for tab otherwise give space in tab
            parent.setContentInsetsAbsolute(0,0);
        }
    }

    private void initViewPager() {
        final ImageView imageview1 = findViewById(R.id.video_tab);
        imageview1.setSelected(true);
        GlideApp.with(this).load(R.drawable.movie_icon).into(imageview1);
        final ImageView imageview2 = findViewById(R.id.image_tab);
        GlideApp.with(this).load(R.drawable.photo).into(imageview2);
        final ImageView imageview3 = findViewById(R.id.music_tab);
        GlideApp.with(this).load(R.drawable.note).into(imageview3);
        final ImageView imageview4 = findViewById(R.id.document_tab);
        GlideApp.with(this).load(R.drawable.doc).into(imageview4);
        viewPager = findViewById(R.id.vew_pager);
        final MyPageAdapter pagerAdapter = new MyPageAdapter(getSupportFragmentManager());
        viewPager.setAdapter(pagerAdapter);
        viewPager.setOffscreenPageLimit(3);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) { }

            @Override
            public void onPageSelected(int position) {
                pagerAdapter.getCurrentFragment(position).
                        requestData(position);
                switch (position) {
                    case 0 :
                        imageview1.setSelected(true);
                        imageview2.setSelected(false);
                        imageview3.setSelected(false);
                        imageview4.setSelected(false);
                        break;
                    case 1 :
                        imageview1.setSelected(false);
                        imageview2.setSelected(true);
                        imageview3.setSelected(false);
                        imageview4.setSelected(false);
                        break;
                    case 2 :
                        imageview1.setSelected(false);
                        imageview2.setSelected(false);
                        imageview3.setSelected(true);
                        imageview4.setSelected(false);
                        break;
                    case 3 :
                        imageview1.setSelected(false);
                        imageview2.setSelected(false);
                        imageview3.setSelected(false);
                        imageview4.setSelected(true);
                        break;
                    default:break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) { }
        });
    }

    public void onSelectPage(View view) {
        ImageView textView1 = findViewById(R.id.video_tab);
        ImageView textView2 = findViewById(R.id.image_tab);
        ImageView textView3 = findViewById(R.id.music_tab);
        ImageView textView4 = findViewById(R.id.document_tab);

        switch (view.getId()) {
            case R.id.video_tab :
                viewPager.setCurrentItem(0);
                textView1.setSelected(true);
                textView2.setSelected(false);
                textView3.setSelected(false);
                textView4.setSelected(false);
                break;
            case R.id.image_tab :
                viewPager.setCurrentItem(1);
                textView1.setSelected(false);
                textView2.setSelected(true);
                textView3.setSelected(false);
                textView4.setSelected(false);
                break;
            case R.id.music_tab :
                viewPager.setCurrentItem(2);
                textView1.setSelected(false);
                textView2.setSelected(false);
                textView3.setSelected(true);
                textView4.setSelected(false);
                break;
            case R.id.document_tab :
                viewPager.setCurrentItem(3);
                textView1.setSelected(false);
                textView2.setSelected(false);
                textView3.setSelected(false);
                textView4.setSelected(true);
                break;
            default:break;
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        actionBarDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
     //  comment this otherwise overriding toggle icon not work
        actionBarDrawerToggle.syncState();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
       if(actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
       // boolean drawerOpen = drawerLayout.isDrawerOpen(drawerList);
        return super.onPrepareOptionsMenu(menu);
    }

}
