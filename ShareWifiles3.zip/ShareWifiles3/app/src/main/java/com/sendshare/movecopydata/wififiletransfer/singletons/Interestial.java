package com.sendshare.movecopydata.wififiletransfer.singletons;

import android.content.Context;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.wifi.mitko.sharewifiles3.R;

public class Interestial {
    private static final Interestial ourInstance = new Interestial();
    private InterstitialAd interestialAd;
    public static Interestial getInstance() {
        return ourInstance;
    }

    private Interestial() { }

    public void createAd(Context context) {
        if (interestialAd == null) {
            interestialAd = new InterstitialAd(context);
            interestialAd.setAdUnitId(context.getString(R.string.real_interestial_unitId));
            interestialAd.loadAd(new AdRequest.Builder().build());
            interestialAd.setAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                    // Load the next interstitial.
                    interestialAd.loadAd(new AdRequest.Builder().build());
                }
            });
        }
    }
    public void showAd() {
        if(interestialAd.isLoaded()) {
            interestialAd.show();
        }
    }
}
