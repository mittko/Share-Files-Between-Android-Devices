package com.sendshare.movecopydata.wififiletransfer.threads;

import android.content.Context;
import android.os.Environment;

import com.sendshare.movecopydata.wififiletransfer.utilities.FileManager;
import com.sendshare.movecopydata.wififiletransfer.utilities.MyConsole;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import static com.sendshare.movecopydata.wififiletransfer.utilities.Konstants.APP_FOLDER;

public class FileReceiverThreadExternalStorage extends Thread {

    private Context context;
    private Socket socket;
    private File dir;
    private InputStream inputStream = null;
    private OutputStream outputStream = null;
    private byte[] bytes1 = new byte[1000*1024];
    public FileReceiverThreadExternalStorage(Context context, Socket socket) {
        this.context = context;
        this.socket = socket;
        File root = Environment.getExternalStorageDirectory();
        dir = new File(root.getAbsolutePath() + File.separator +  APP_FOLDER);
        if(!dir.exists()) {
            dir.mkdir();
        }
      //  MyConsole.println(dir.toString());
    }
    @Override
    public void run() {
        super.run();
        try {
            inputStream = socket.getInputStream();
            int size = inputStream.read();
            byte[] bytes = new byte[size];
            int count = inputStream.read(bytes);
            String filePath = new String(bytes,0,count);
            int index = filePath.lastIndexOf("/");
            if(index != -1) {
                String name = filePath.substring(index + 1);
                File file = new File(dir, name);
                inputStream = socket.getInputStream();
                outputStream = new FileOutputStream(file);
                int count1;
                while ((count1 = inputStream.read(bytes1)) > 0) {
                    outputStream.write(bytes1, 0, count1);
                }
                outputStream.flush();

                // refresh media in db
                FileManager.refreshMediaStoreDB(context,file.getAbsolutePath());
            } else {
                MyConsole.println("Wrong file path !");
            }
        } catch (IOException e) {
            MyConsole.println(e.getMessage()+"");
        } finally {
            try {
                if(inputStream != null) {
                    inputStream.close();
                }
                if(outputStream != null) {
                    outputStream.close();
                }
                if(socket != null) {
                    socket.close();
                }
            }catch (IOException e) {
                MyConsole.println(e.getMessage()+"");
            }
        }
    }


}
