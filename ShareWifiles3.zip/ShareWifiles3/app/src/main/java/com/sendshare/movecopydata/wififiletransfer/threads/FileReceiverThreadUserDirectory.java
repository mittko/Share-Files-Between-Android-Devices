package com.sendshare.movecopydata.wififiletransfer.threads;

import android.content.Context;
import android.net.Uri;

import androidx.documentfile.provider.DocumentFile;

import com.sendshare.movecopydata.wififiletransfer.utilities.FileManager;
import com.sendshare.movecopydata.wififiletransfer.utilities.MyConsole;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import static com.sendshare.movecopydata.wififiletransfer.utilities.Konstants.APP_FOLDER;

public class FileReceiverThreadUserDirectory extends  Thread {
    private Context context;
    private Socket socket;
    private Uri persistableUri;

    public FileReceiverThreadUserDirectory(Context context, Socket socket, Uri persistableUri) {
        this.context = context;
        this.socket = socket;
        this.persistableUri = persistableUri;
  //   Version Code 6 ->   sdcardUri = FileManager.getUri(FileManager.SD_CARD_URI,context);
    }
    @Override
    public void run() {
        super.run();
        try {
            writeToFile(persistableUri,socket.getInputStream());
      /*     Version Code 6 ->  writeToFile(sdcardUri,socket.getInputStream());*/
        } catch (IOException e) {
          MyConsole.println(e.getMessage()+"");
        }
    }


    private void writeToFile(Uri uri, InputStream inputStream) {
     //   MyConsole.println("1.2");
     //   MyConsole.println("URI "+uri.toString());
        DocumentFile pickedDir;
        try {
             pickedDir = DocumentFile.fromTreeUri(context, uri);
        } catch (IllegalArgumentException e) {
            MyConsole.println("from FileReceiverThreadUserDirectory "+e.getMessage());
       //     MyDialog.showDialog(e.getMessage()+"",context);
            return;
        }
      //  MyConsole.println("1.3");
        // List all existing files inside picked directory
       /* if(pickedDir != null) {
            for (DocumentFile file : pickedDir.listFiles()) {
                Log.d("tag", "Found file " + file.getName() + " with size " + file.length());
            }
        }*/
        // Create a new file and write into it
        if(pickedDir != null) {
            int count1;
            OutputStream outputStream = null;
          //  String extension = "";
            String stringFromBytes;
            String name;
            try {
         //       MyConsole.println("1.4");
                int size = inputStream.read();
       //         MyConsole.println("1.5");
                byte[] bytes1 = new byte[size];
                count1 = inputStream.read(bytes1);
       //         MyConsole.println("1.6");
                stringFromBytes = new String(bytes1,0,count1);
       //         MyConsole.println("file = "+stringFromBytes);
                int index = stringFromBytes.lastIndexOf("/");
                if(index != -1) {
                    name = stringFromBytes.substring(index + 1);
                    //         MyConsole.println("1.7");
           /*     int extensionIndex = stringFromBytes.lastIndexOf(".");
                extension = stringFromBytes.substring(extensionIndex);*/
                    //         MyConsole.println("1.8");
                    String mimeType = FileManager.getMimeType(stringFromBytes);
         //           MyConsole.println("MIME TYPE = " + mimeType);

                    DocumentFile directoryToSave = pickedDir.findFile(APP_FOLDER);
                    if(directoryToSave == null || !directoryToSave.exists()) {
                            directoryToSave = pickedDir.createDirectory(APP_FOLDER);
                    }
                     if(directoryToSave != null) {
                    DocumentFile newFile = directoryToSave.createFile(mimeType, name);// text/+file extension
                    if (newFile != null) {
              //          MyConsole.println("PATH "+newFile.getUri().toString());
                        byte[] bytes = new byte[1000 * 1024];
                        //        MyConsole.println("1.10");
                        outputStream = context.getContentResolver().openOutputStream(newFile.getUri());
                        //        MyConsole.println("1.11");
                        if (outputStream != null) {
                            int count;
                            while ((count = inputStream.read(bytes)) > 0) {
                                outputStream.write(bytes, 0, count);
                            }
                            outputStream.flush();
                            //    refresh media in db
                            FileManager.refreshMediaStoreDB(context,
                                    pickedDir.getUri().toString());
                         }
                       } else {
                        MyConsole.println("Can not be created file on SD Card!");
                     }
                    } else {
                         MyConsole.println("Can not be created directory on SD Card!");
                     }
                } else {
                    MyConsole.println("Wrong file path !");
                }
       //         MyConsole.println("1.9");
            } catch (IOException e) {
                MyConsole.println("from FileReceiverThreadUserDirectory "+ e.getMessage());
            }finally {
                try {
                    if (outputStream != null) {
                        outputStream.close();
                    }
                    inputStream.close();
                    if (socket != null) {
                        socket.close();
                    }
                } catch (IOException e) {
                    MyConsole.println("from FileReceiverThreadUserDirectory "+e.getMessage());
                }
            }
        } else {
            MyConsole.println("Directory not selected !");
        }
    }
    // url = file path or whatever suitable URL you want.
}
