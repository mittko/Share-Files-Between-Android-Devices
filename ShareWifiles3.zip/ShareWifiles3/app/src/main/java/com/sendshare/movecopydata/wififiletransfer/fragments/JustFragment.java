package com.sendshare.movecopydata.wififiletransfer.fragments;


import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sendshare.movecopydata.wififiletransfer.adapters.ListRow;
import com.sendshare.movecopydata.wififiletransfer.adapters.RecyclerViewAdapter3;
import com.sendshare.movecopydata.wififiletransfer.interfaces.ListRefresher;
import com.sendshare.movecopydata.wififiletransfer.listeners.ScrollListenerPagination;
import com.sendshare.movecopydata.wififiletransfer.media.GetAudioFiles;
import com.sendshare.movecopydata.wififiletransfer.media.GetDocumentFiles2;
import com.sendshare.movecopydata.wififiletransfer.media.GetPicturesFiles;
import com.sendshare.movecopydata.wififiletransfer.media.GetVideoFiles;
import com.sendshare.movecopydata.wififiletransfer.utilities.MyConsole;
import com.wifi.mitko.sharewifiles3.R;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import static com.sendshare.movecopydata.wififiletransfer.utilities.Konstants.ITEM_TO_SCROLL;

/**
 * A simple {@link Fragment} subclass.
 */
public class JustFragment extends Fragment implements ListRefresher {

    private RecyclerViewAdapter3 recyclerViewAdapter;
    private int scrollFrom = 0;
    private int pageNumber;
    private static final String stringPage = "stringPage";
    private RecyclerView recyclerView = null;
    public JustFragment() {
        // Required empty public constructor
    }

    public static Fragment getInstance(int page) {
        JustFragment justFragment = new JustFragment();
        Bundle arguments = new Bundle();
        arguments.putInt(stringPage,page);
        justFragment.setArguments(arguments);
        return justFragment;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pageNumber = getArguments().getInt(stringPage);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_just, container, false);
        initRecyclerView(view);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if(pageNumber == 0) {
            requestData(0);
        }
    }

    private void initRecyclerView(View view) {
        recyclerViewAdapter = new RecyclerViewAdapter3(getActivity(),pageNumber);
        recyclerView = view.findViewById(R.id.files_recyclerview);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addOnScrollListener(new ScrollListenerPagination(layoutManager) {
            @Override
            public void onLoadMoreItems() {
               requestData(pageNumber);
            }
        });
        recyclerView.setAdapter(recyclerViewAdapter);
    }

    @Override
    public void updateList(ArrayList<String> arrayList) {
        ArrayList<ListRow> newList = new ArrayList<>();
        for(String str : arrayList) {
            newList.add(new ListRow(str,false,
                    true));
        }
        recyclerViewAdapter.updateList(newList);
    }

    public void requestData(int page) {
        switch (page) {
            case 0 :
                GetVideoFiles getVideoFiles =
                        new GetVideoFiles(scrollFrom,
                                new WeakReference<>(getContext()),this);
                getVideoFiles.execute();
                break;
            case 1 :
                GetPicturesFiles getPicturesFiles =
                        new GetPicturesFiles(scrollFrom,new WeakReference<>(
                                getContext()),this);
                getPicturesFiles.execute();
                break;
            case 2 :
                GetAudioFiles getAudioFiles =
                        new GetAudioFiles(scrollFrom,
                                new WeakReference<Context>(getContext()),this);
                getAudioFiles.execute();
                break;
            case 3 :
                GetDocumentFiles2 getDocumentFiles =
                        new GetDocumentFiles2(scrollFrom,new WeakReference<Context>(
                                getContext()),this);
                getDocumentFiles.execute();
                break;
            default:break;
        }
        scrollFrom += ITEM_TO_SCROLL;
    }

    @Override
    public void onStop() {
        super.onStop();
        recyclerViewAdapter.clearSelectedItems();
        MyConsole.println("ON STOP()");
    }
}
