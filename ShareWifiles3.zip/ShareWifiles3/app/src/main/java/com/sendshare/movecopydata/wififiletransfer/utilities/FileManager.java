package com.sendshare.movecopydata.wififiletransfer.utilities;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.webkit.MimeTypeMap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.HashMap;

import static android.content.Context.MODE_PRIVATE;

public class FileManager {
    public static HashMap<String, ArrayList<String>>
            hashMap = new HashMap<>();
    public static HashMap<String, String> dirMap = new HashMap<>();

    public static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    public static String SD_CARD_URI = "sd_card_uri";
    private static final String userDirectory = "userDirectory";

    public static ArrayList<String> getDirs() {
        ArrayList<String> dirs = new ArrayList<>();
        dirs.add("Videos");
        dirs.add("Pictures");
        dirs.add("Documents");
        dirs.add("Audios");
        return  dirs;
    }

  @TargetApi(Build.VERSION_CODES.M)
  public static boolean verifyStoragePermissions(Context context) {
      // Check if we have write permission
      int permission = ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE);
      if(permission != PackageManager.PERMISSION_GRANTED) {
          ActivityCompat.requestPermissions(
                      (AppCompatActivity)context,
                      PERMISSIONS_STORAGE,
                      REQUEST_EXTERNAL_STORAGE);
          return false;
      }
      return true;
   //   MyConsole.println("NEEDED ONLY FROM MARSHMALLOW AND ABOVE BELOW PERMISSION IS GRANTED AUTOMATICALLY");
  }
    @TargetApi(Build.VERSION_CODES.M)
    public static void requestCameraPermissions(AppCompatActivity appCompatActivity) {
        if(ContextCompat.checkSelfPermission(
                appCompatActivity,
                Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            String[] permissions =
                    {Manifest.permission.CAMERA};
            ActivityCompat.requestPermissions(
                    appCompatActivity, permissions,
                    7);
        }
//   MyConsole.println("NEEDED ONLY FROM MARSHMALLOW AND ABOVE");
    }



    public static String getMimeType(String url) {
        String type = null;
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
    //    MyConsole.println("MIME = "+type);
        return type;
    }

    /*public static void openFile(String url, Context context) {
        // NOT WORK ON TARGET API >= 24 !!!
        Intent intent = new Intent(Intent.ACTION_VIEW);
        String mimeType = getMimeType(url);
        File file = new File(url);
        if(file.exists()) {
            intent.setDataAndType(Uri.fromFile(file), mimeType);
             intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            try {
                context.startActivity(Intent.createChooser(intent, "Share image"));
         //       context.startActivity(intent);
            } catch (ActivityNotFoundException e) {
                MyConsole.println("from FileManger "+e.getMessage());
            }
        } else {
            MyConsole.println("from FileManager File not found!!!");
        }
    }*/

   /* public static void shareFile(String url, Context context) {
        // Not work on Target Api >= 27
        Intent intentShareFile = new Intent(Intent.ACTION_SEND);
        File file = new File(url);
        String mimeType = getMimeType(url);
        if(file.exists()) {
            intentShareFile.setType(mimeType);
            intentShareFile.putExtra(Intent.EXTRA_STREAM, Uri.fromFile( file));
            int index = url.lastIndexOf("/");
            String fileName = null;
            if(index != -1) {
                fileName = url.substring(index + 1);
            } else {
                fileName = "File";
            }
            intentShareFile.putExtra(Intent.EXTRA_SUBJECT,
                    fileName);
            intentShareFile.putExtra(Intent.EXTRA_TEXT, "Share File...");
            try {
                context.startActivity(Intent.createChooser(intentShareFile, "Share File"));
            } catch (ActivityNotFoundException e) {
                MyConsole.println("from FileManager "+e.getMessage());
            }
        } else {
            MyConsole.println("from FileManager File not found!!!");
        }
    }
*/

 //  Version Code 6 ->   @TargetApi(Build.VERSION_CODES.KITKAT)
   /* public static boolean checkPersistedUriPermissions(Context context){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {// !!!!! NOT VERIFIED ATENTION
            List<UriPermission> list = context.getContentResolver().getPersistedUriPermissions();
            for (int i = 0; i < list.size(); i++) {
                // da se proveri korektnostta
                //     Log.e("tag",list.get(i).getUri().toString());
                if (list.get(i).isWritePermission()) {// && list.get(i).getUri() == myUri
                    //        Log.e("tag",list.get(i).getUri().getPath());
                    return true;
                }
            }
            return false;
        }
        return true;
    }*/


    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static void grandPermission(Context context) {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            ( (AppCompatActivity)context).startActivityForResult(intent,25);
            MyConsole.println("ACTION_OPEN_DOCUMENT_TREE");
        } else if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("*/*");
            intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            ( (AppCompatActivity)context).startActivityForResult(intent,25);
            MyConsole.println("ACTION_OPEN_DOCUMENT");
        } else {
           // MyConsole.println("ACTION_GET_CONTENT");
        }
    }

    public static void saveUserUri(Uri uri,Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("some tag",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(userDirectory,uri.toString());
        editor.apply();
     }
    public static Uri getUserUri(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("some tag",MODE_PRIVATE);
        return Uri.parse(sharedPreferences.getString(userDirectory,"default"));
    }

   /* Version code 6 -> public static void saveStorageDirectory(int storage,Context context) {
        SharedPreferences sharedPreferences =
                context.getSharedPreferences("storagePreferrences",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("storageDirectory",storage);
        editor.apply();
    }
    public static int getStorageDirectory(Context context) {
        SharedPreferences sharedPreferences =
                context.getSharedPreferences("storagePreferrences", MODE_PRIVATE);
        return sharedPreferences.getInt("storageDirectory",MODE_PRIVATE);
    }
*/

    public static void refreshMediaStoreDB(Context context, String file) {
        MediaScannerConnection.scanFile(context,
                new String[]{file},
                null
                , new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                        //        MyConsole.println("onScanCompleted 222 " + path +" " +uri.getPath());
                    }
                });
    }

    public static void refreshMediaStoreDB(Context context, String[] paths) {
        // !!!  android.app.ServiceConnectionLeaked: Activity MainActivity has leaked ServiceConnection
        MediaScannerConnection.scanFile(context.getApplicationContext(),
                paths,
                null
                , new MediaScannerConnection.OnScanCompletedListener() {
                    public void onScanCompleted(String path, Uri uri) {
                //        MyConsole.println("onScanCompleted 222 " + path +" " +uri.getPath());
                    }
                });
    }

    public static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 123;

    public static boolean checkPermissionREAD_EXTERNAL_STORAGE(
            final Context context) {
        int currentAPIVersion = Build.VERSION.SDK_INT;
        if (currentAPIVersion >= android.os.Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(context,
                    Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(
                        (Activity) context,
                        Manifest.permission.READ_EXTERNAL_STORAGE)) {
                    showDialog("External storage", context,
                            Manifest.permission.READ_EXTERNAL_STORAGE);

                } else {
                        try {
                            ActivityCompat
                                    .requestPermissions(
                                            (Activity) context,
                                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                                            MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
                        } catch (SecurityException e) {

                        }
                    Log.e("fuck ","you");
                }
                return false;
            } else {
                return true;
            }

        } else {
            return true;
        }
    }
    public static void showDialog(final String msg, final Context context,
                           final String permission) {
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(context);
        alertBuilder.setCancelable(true);
        alertBuilder.setTitle("Permission necessary");
        alertBuilder.setMessage(msg + " permission is necessary");
        alertBuilder.setPositiveButton(android.R.string.yes,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        ActivityCompat.requestPermissions((Activity) context,
                                new String[] { permission },
                                MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
                    }
                });
        AlertDialog alert = alertBuilder.create();
        alert.show();
    }

}
