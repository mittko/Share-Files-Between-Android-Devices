package com.sendshare.movecopydata.wififiletransfer.servers;

import android.content.Context;
import android.net.Uri;
import android.os.Build;

import com.sendshare.movecopydata.wififiletransfer.threads.FileReceiverThreadExternalStorage;
import com.sendshare.movecopydata.wififiletransfer.threads.FileReceiverThreadUserDirectory;
import com.sendshare.movecopydata.wififiletransfer.utilities.FileManager;
import com.sendshare.movecopydata.wififiletransfer.utilities.Konstants;
import com.sendshare.movecopydata.wififiletransfer.utilities.MyConsole;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class MyServer extends Thread {

    private static ServerSocket serverSocket;


    private Context context;
    private ArrayList<Thread> threads = new ArrayList<>();
    private final Object object = new Object();
    private void interruptThreads() {
        for(Thread thread : threads) {
            thread.interrupt();
        }
    }
    public static int getServerPort() {
        return serverSocket.getLocalPort();
    }
    public MyServer(Context context) {
        this.context = context;
        try {
            serverSocket = new ServerSocket(Konstants.SERVER_PORT);//(0);
        } catch (IOException e) {
           MyConsole.println("from MyServer "+e.getMessage());
        }
    }
    @Override
    public void run() {
        super.run();
        while (!isInterrupted()) {
            try {
                Socket socket = null;
                synchronized (this) {
                    socket = serverSocket.accept();
                }
                if(Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
                    FileReceiverThreadExternalStorage
                            fileReceiverThreadExternalStorage =
                            new FileReceiverThreadExternalStorage(context,socket);
                    fileReceiverThreadExternalStorage.start();
                    threads.add(fileReceiverThreadExternalStorage);
                } else {
                     Uri persistableUri = FileManager.getUserUri(context);
                     if(persistableUri == null || persistableUri.toString().equals("default")) {
                         FileReceiverThreadExternalStorage
                                 fileReceiverThreadExternalStorage =
                                 new FileReceiverThreadExternalStorage(context,socket);
                         fileReceiverThreadExternalStorage.start();
                         threads.add(fileReceiverThreadExternalStorage);
                     } else {
                         FileReceiverThreadUserDirectory fileReceiverThreadUserDirectory =
                                 new FileReceiverThreadUserDirectory(context,socket,persistableUri);
                         fileReceiverThreadUserDirectory.start();
                         threads.add(fileReceiverThreadUserDirectory);
                     }

                }
              /*   Version Code 6 ->  boolean hasPermission = FileManager.checkPersistedUriPermissions(context);
                if(!hasPermission) {
                    FileReceiverThreadExternalStorage
                            fileReceiverThreadInternalStorage =
                            new FileReceiverThreadExternalStorage(context,socket);
                    fileReceiverThreadInternalStorage.start();
                    threads.add(fileReceiverThreadInternalStorage);
                } else {
                    int storageDirectory = FileManager.getStorageDirectory(context);
                    if(storageDirectory == INTERNAL_STORAGE) {
                        FileReceiverThreadExternalStorage
                                fileReceiverThreadInternalStorage =
                                new FileReceiverThreadExternalStorage(context,socket);
                        fileReceiverThreadInternalStorage.start();
                        threads.add(fileReceiverThreadInternalStorage);
                    } else if(storageDirectory == EXTERNAL_STORAGE) {
                        FileReceiverThreadUserDirectory fileReceiverThreadSDCard =
                                new FileReceiverThreadUserDirectory(context,socket);
                        fileReceiverThreadSDCard.start();
                        threads.add(fileReceiverThreadSDCard);
                    }
                }*/

            } catch (IOException e) {
                MyConsole.println("from MySever "+e.getMessage());
            }

         /*   try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                MyConsole.println("MyServer thread intterupted ->  from MyServer " + e.getMessage());
            }*/
        }
    }

    @Override
    public void interrupt() {
        interruptThreads();

        // За да прекъсна нишката трябва да затворя сокета
        try {
            if(serverSocket != null)
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        super.interrupt();
    }
}
