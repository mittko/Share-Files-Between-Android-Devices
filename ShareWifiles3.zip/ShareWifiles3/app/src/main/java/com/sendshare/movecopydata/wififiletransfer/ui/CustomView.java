package com.sendshare.movecopydata.wififiletransfer.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

import com.sendshare.movecopydata.wififiletransfer.interfaces.VisualizeDataTransfer;

public class CustomView extends View implements VisualizeDataTransfer {
    private Paint paint = new Paint();
    private Paint textPaint = new Paint();
    private Paint  percentPaint = new Paint();
    private Rect rect;
    private int WIDTH;
    private int HEIGHT;
    private String text = " 0 %";
    private String filepath;

    public void setFilepath(String filepath) {
        int index = filepath.lastIndexOf("/");
        if(index != -1) {
            this.filepath = filepath.substring(index+1);
        } else {
            this.filepath = filepath;
        }
    }

    private void setColor(int color) {
        paint.setColor(color);
    }
    public void setWIDTH(int WIDTH) {
        this.WIDTH = WIDTH;
    }
    public void setHEIGHT(int HEIGHT) {
        this.HEIGHT = HEIGHT;
        int spSize = HEIGHT/20;
        float scaledSizeInPixels = spSize * getResources().getDisplayMetrics().scaledDensity;
        textPaint.setTextSize(scaledSizeInPixels);
        percentPaint.setTextSize(scaledSizeInPixels);
    }

    public CustomView(Context context) {
        super(context);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.GREEN);
        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setColor(Color.BLACK);
        percentPaint.setStyle(Paint.Style.FILL);
     //   percentPaint.setColor(Color.parseColor("#FFA60C"));
        rect = new Rect();
    }


    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawRect(rect,paint);
        canvas.drawText(filepath + text,0,(int)(HEIGHT/1.6),textPaint);
        //   canvas.drawText(text,(int)(WIDTH/2) - (textPaint.measureText(text)/2),(int)(HEIGHT),percentPaint);
    }


    @Override
    public void visualize(double value) {
        float percentage = ((float)value) * (float)WIDTH;
        rect.set(0,HEIGHT/2,(int)percentage,(int)(HEIGHT/1.5));
        if(value < 1.0) {
            this.text = " " + (int)(value * 100) + " %";
        } else {
            this.text = " done !!!";
        }
        invalidate();
    }

    @Override
    public void handleConnectionError(String text) {

    }
    /*@Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

        setMeasuredDimension(widthMeasureSpec, heightMeasureSpec);

    }*/

}
