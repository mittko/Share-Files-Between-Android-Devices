/*
package com.sendshare.movecopydata.wififiletransfer.activities;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.GridView;
import android.widget.LinearLayout;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;
import com.sendshare.movecopydata.wififiletransfer.adapters.GridViewAdapter;
import com.sendshare.movecopydata.wififiletransfer.tasks.FileTransferTask;
import com.sendshare.movecopydata.wififiletransfer.ui.CircleCustomView;
import com.sendshare.movecopydata.wififiletransfer.utilities.MyUtility;
import com.wifi.mitko.sharewifiles3.R;

import java.io.IOException;
import java.util.ArrayList;

public class ScanActivity extends AppCompatActivity {
    private BarcodeDetector barcodeDetector;
    private CameraSource cameraSource;
    private SurfaceView cameraView;
    private boolean barcodeDetected = false;
    private ArrayList<FileTransferTask> fileTransferTasks =
            new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send);
        initActionBar();
        initScanner();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }


    private void initScanner() {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        display.getMetrics(displayMetrics);
        int WIDTH = displayMetrics.widthPixels;//
        int HEIGHT = displayMetrics.heightPixels;//
        cameraView = (SurfaceView) findViewById(R.id.surface_view);

        barcodeDetector = new BarcodeDetector.Builder(getApplicationContext())
                .setBarcodeFormats(Barcode.QR_CODE)
                .build();

        cameraSource = new CameraSource.Builder(getApplicationContext(), barcodeDetector)
                .setRequestedPreviewSize(WIDTH, HEIGHT)
                .setAutoFocusEnabled(true) //you should add this feature
                .build();

        cameraView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                try {
                    //noinspection MissingPermission
                    try {
                      */
/*  if(ContextCompat.checkSelfPermission(
                                ScanActivity.this,
                                Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                            String[] permissions =
                                    {Manifest.permission.CAMERA};
                            ActivityCompat.requestPermissions(
                                    ScanActivity.this, permissions,
                                    7);
                        }*//*

                        cameraSource.start(cameraView.getHolder());
                    }catch (SecurityException e) {
                        Log.e("from ScanActivity ",e.getMessage()+"");
                    }
                } catch (IOException ex) {
                    Log.e("from ScanActivity ",ex.getMessage()+"");
                }
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
            //    cameraSource.stop();
                cameraSource.release();
            }
        });

        barcodeDetector.setProcessor(new Detector.Processor<com.google.android.gms.vision.barcode.Barcode>() {
            @Override
            public void release() {
            }

            @Override
            public void receiveDetections(Detector.Detections detections) {
                final SparseArray<Barcode> barcodes = detections.getDetectedItems();
                if (barcodes.size() != 0 && !barcodeDetected) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            SurfaceView cameraView = (SurfaceView) findViewById(R.id.surface_view);
                            cameraView.setVisibility(View.GONE);

                       */
/*     ScrollView scrollView = findViewById(R.id.scrollview_customviews);
                            scrollView.setVisibility(View.VISIBLE);*//*

                            GridView gridView =
                                    findViewById(R.id.gridview_circlecustomview);
                            gridView.setVisibility(View.VISIBLE);
                        }
                    });


                    String[] ip_port = barcodes.valueAt(0).displayValue.split("\\^");
                    String ip = ip_port[0];
                    int port =  Integer.parseInt(ip_port[1]);
           //         MyConsole.println("IP " + ip);
             //       LinearLayout linearLayout = findViewById(R.id.parent_layout);

                    ArrayList<CircleCustomView> circleCustomViews =
                            new ArrayList<>();
                    for(String str : MyUtility.filesToSend) {
                        int lastSplash = str.lastIndexOf("/");
                        String fileName = "";
                        if(lastSplash != -1) {
                            fileName = str.substring(lastSplash+1);
                        }
                        CircleCustomView circleCustomView =
                                addCustomView2(fileName);
                        circleCustomViews.add(circleCustomView);
                    }
                    GridView gridView =
                            findViewById(R.id.gridview_circlecustomview);
                    gridView.setAdapter(new GridViewAdapter(circleCustomViews));
                    int v = 0;
                    for(String filepath : MyUtility.filesToSend) {
                   //     CustomView customView = addCustomView(linearLayout, filepath);
                        FileTransferTask fileTransferTask =
                                new FileTransferTask(ip, port,
                                        filepath, circleCustomViews.get(v));
                        v++;
                        fileTransferTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
                        fileTransferTasks.add(fileTransferTask);
                    }
                    barcodeDetected = true;
                }
            }
        });
    }
    private CircleCustomView addCustomView2(String fileName) {
        int viewHeight =
                (int)( MyUtility.getHeightInPixels(this)/4);
        int viewWidth =
                (int)(MyUtility.getWidthInPixels(this));///2);
        LinearLayout.LayoutParams layoutParams =
                new LinearLayout.LayoutParams(viewWidth,
                        viewHeight);
        final CircleCustomView customView = new CircleCustomView(fileName,this);
        customView.setLayoutParams(layoutParams);
        return customView;
    }
    */
/*private CustomView addCustomView(LinearLayout linearLayout, String filepath) {
        int viewHeight = MyUtility.dpToPx(70,this);
        LinearLayout.LayoutParams layoutParams =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                        viewHeight);
        final CustomView customView = new CustomView(this);
        customView.setFilepath(filepath);
        customView.setLayoutParams(layoutParams);
        customView.setWIDTH((int)MyUtility.getWidthInPixels(this));
        customView.setHEIGHT(viewHeight);
        customView.setColor(Color.parseColor("#267F00"));
        linearLayout.addView(customView);
        return customView;
    }*//*


    private void destroyTasks() {
        for(FileTransferTask tasks : fileTransferTasks) {
            tasks.cancel(true);
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
//        cameraSource.release();
        barcodeDetector.release();
        destroyTasks();
    }


    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }
    private void initActionBar() {
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

}
*/
